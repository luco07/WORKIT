let div = document.getElementById("div");
document.getElementById("unirse").addEventListener("click", () =>  {
    document.body.classList.remove("hidden");
    div.style.display = "none";
  });
  